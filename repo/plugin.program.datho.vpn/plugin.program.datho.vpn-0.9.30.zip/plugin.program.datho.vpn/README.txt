Datho VPN
This add-on allows you to use Datho VPN service on Kodi (XBMC).  Please note that a subscription to Datho VPN is required to use this add-on. 

Additionally, users of this add-on must download additional software, or take additional measures when starting XBMC if you use the following OS:

Windows - Requires OpenVPN desktop client & requires XBMC to be run as Adminstrator 
Android - Requires Datho VPN for XBMC & OpenVPN for Android apks (download from Google Play)
RaspBMC - Requires OpenVPN.  Install via SSL connection and use command 'sudo apt-get install openvpn'

Please note that this add-on does not support iOS.  